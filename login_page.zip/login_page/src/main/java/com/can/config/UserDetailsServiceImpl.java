package com.can.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.can.Model.UserDtls;
import com.can.Repo.UserRepository;
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

    @Autowired
    private UserRepository userRepo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        logger.info("Attempting to load user by email: {}", email);
        UserDtls user = userRepo.findByEmail(email);
        if (user == null) {
            logger.error("User not found: {}", email);
            throw new UsernameNotFoundException("User not available!");
        }
        logger.info("User found: {}", email);
        return new CustomUserDetails(user);
    }
}
