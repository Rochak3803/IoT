package com.can.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.can.Model.Employee;
import com.can.service.EmpService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/emp")
public class EmpController {

    @Autowired
    private EmpService service;

    @GetMapping(value = "/addemp")
    public String showAddEmployeeForm() {
        return "addEmp"; // Make sure "addEmp" is the correct name of your Thymeleaf HTML template
    }

    @PostMapping("/register")
    public String empRegister(@ModelAttribute Employee e, @RequestPart("pdfFile") MultipartFile file, HttpSession session) {
        try {
            service.addEmp(e, file); // Save employee along with the PDF file
            session.setAttribute("msg", "Book Added Successfully with PDF...");
        } catch (IOException ex) {
            session.setAttribute("msg", "Failed to upload PDF. Please try again.");
            ex.printStackTrace();
        }
        return "redirect:/emp/success";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable int id, Model m) {
        Employee e = service.getEmpById(id);
        m.addAttribute("emp", e);
        return "edit";
    }

    @PostMapping("/update")
    public String updateEmp(@ModelAttribute Employee e, HttpSession session) {
        try {
            service.addEmp(e, null); // For update, we won't change the PDF file
            session.setAttribute("msg", "Employee Data Updated Successfully...");
        } catch (IOException ex) {
            session.setAttribute("msg", "Error during update.");
            ex.printStackTrace();
        }
        return "redirect:/emp/success";
    }

    @GetMapping("/success")
    public String success(Model model, HttpSession session) {
        Object msg = session.getAttribute("msg");
        if (msg != null) {
            model.addAttribute("msg", msg);
            session.removeAttribute("msg");
        }
        List<Employee> emp = service.getAllEmp();
        model.addAttribute("emp", emp);
        return "ind";
    }

    @GetMapping("/delete/{id}")
    public String deleteEmp(@PathVariable int id, HttpSession session) {
        service.deleteEmp(id);
        session.setAttribute("msg", "Employee Data Deleted Successfully...");
        return "redirect:/emp/success";
    }
}
