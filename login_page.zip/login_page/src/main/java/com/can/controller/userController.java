package com.can.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.can.Model.Employee;
import com.can.Model.UserDtls;
import com.can.Repo.UserRepository;
import com.can.service.EmpService;
import com.can.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class userController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private UserRepository userRepo;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncode;
    
    @Autowired
    private EmpService service;
    
    @GetMapping("/")
    public String home(Model m) {
        List<Employee> emp = service.getAllEmp();
        m.addAttribute("emp", emp);
        return "ind";
    }

    @GetMapping("/changepassword")
    public String loadChangePasswordPage() {
        return "Change_Password";
    }

    @PostMapping("/updatePassword")
    public String changePassword(Principal p, @RequestParam("oldPass") String oldPass, @RequestParam("newPass") String newPass, HttpSession session) {
        String email = p.getName();
        UserDtls loginUser = userRepo.findByEmail(email);
        boolean isMatch = passwordEncode.matches(oldPass, loginUser.getPassword());

        if (isMatch) {
            loginUser.setPassword(passwordEncode.encode(newPass));
            UserDtls updatedUser = userRepo.save(loginUser);
            if (updatedUser != null) {
                session.setAttribute("msg", "Password changed successfully!");
            } else {
                session.setAttribute("msg", "Something went wrong!");
            }
        } else {
            session.setAttribute("msg", "Old password incorrect");
        }
        return "redirect:/user/success";
    }

    @GetMapping("/success")
    public String successPage(Model model, HttpSession session) {
        Object msg = session.getAttribute("msg");
        if (msg != null) {
            model.addAttribute("msg", msg);
            session.removeAttribute("msg");
        }
        return "index";
    }
}
