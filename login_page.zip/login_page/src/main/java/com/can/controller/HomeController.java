package com.can.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.can.Model.UserDtls;
import com.can.Repo.UserRepository;
import com.can.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private BCryptPasswordEncoder passwordEncode;

    @ModelAttribute
    private void userDetails(Model m, Principal p) {
        if (p != null) {
            String email = p.getName();
            UserDtls user = userRepo.findByEmail(email);
            m.addAttribute("user", user);
        }
    }

    @GetMapping("/home")
    public String index() {
        return "index";
    }

    @GetMapping("/signin")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @GetMapping("/forget")
    public String forgetPage() {
        return "forget";
    }

    @PostMapping("/createUser")
    public String createUser(@ModelAttribute UserDtls user, HttpSession session) {
        boolean exists = userService.checkEmail(user.getEmail());
        if (exists) {
            session.setAttribute("msg", "Email ID already exists!");
        } else {
            UserDtls userDtls = userService.creatUser(user);
            if (userDtls != null) {
                session.setAttribute("msg", "SignUp is successful!");
            } else {
                session.setAttribute("msg", "Error in server!");
            }
        }
        return "redirect:/home/success";
    }

    @GetMapping("/home/success")
    public String success(Model model, HttpSession session) {
        Object msg = session.getAttribute("msg");
        if (msg != null) {
            model.addAttribute("msg", msg);
            session.removeAttribute("msg");
        }
        return "register";
    }
    @GetMapping("/home/signin")
    public String loginn() {
        return "login";
    }
    @GetMapping("/home/register")
    public String registe() {
        return "register";
    }

    @PostMapping("/sendOtp")
    public String sendOtp(@RequestParam("email") String email, HttpSession session) {
        String emailOtp = userService.generateOtp();
        session.setAttribute("emailOtp", emailOtp);
        session.setAttribute("email", email);
        session.setAttribute("msg", "OTP has been sent to your email.");

        userService.sendOtpToEmail(email, emailOtp);

        return "redirect:/verifyOtp";
    }

    @GetMapping("/verifyOtp")
    public String verifyOtpPage() {
        return "verifyOtp";
    }

    @PostMapping("/verifyOtp")
    public String verifyOtp(@RequestParam("emailOtp") String emailOtp, HttpSession session, RedirectAttributes redirectAttributes) {
        String sessionEmailOtp = (String) session.getAttribute("emailOtp");

        if (sessionEmailOtp != null && sessionEmailOtp.equals(emailOtp)) {
            session.removeAttribute("emailOtp");
            return "redirect:/resetPassword";
        } else {
            redirectAttributes.addFlashAttribute("msg", "Invalid OTP. Please try again.");
            return "redirect:/verifyOtp";
        }
    }

    @GetMapping("/resetPassword")
    public String resetPasswordPage() {
        return "resetPassword";
    }

    @PostMapping("/resetPassword")
    public String resetPassword(@RequestParam("newPass") String newPass, HttpSession session) {
        String email = (String) session.getAttribute("email");
        UserDtls loginUser = userRepo.findByEmail(email);

        if (loginUser != null) {
            loginUser.setPassword(passwordEncode.encode(newPass));
            UserDtls updatedUser = userRepo.save(loginUser);

            if (updatedUser != null) {
                session.setAttribute("msg", "Password changed successfully!");
            } else {
                session.setAttribute("msg", "Something went wrong!");
            }
        } else {
            session.setAttribute("msg", "User not found!");
        }

        return "redirect:/home/successful";
    }

    @GetMapping("/home/successful")
    public String successful(Model model, HttpSession session) {
        Object msg = session.getAttribute("msg");
        if (msg != null) {
            model.addAttribute("msg", msg);
            session.removeAttribute("msg");
        }
        return "login";
    }
}
