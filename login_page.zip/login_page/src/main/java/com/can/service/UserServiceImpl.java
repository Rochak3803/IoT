//package com.can.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.can.Model.UserDtls;
//import com.can.Repo.UserRepository;
//
//@Service
//public class UserServiceImpl implements UserService{
//	
//	@Autowired
//	private UserRepository userRepo;
//	
//	@Autowired
//	private BCryptPasswordEncoder passwordEncode;
//	@Override
//	public UserDtls creatUser(UserDtls user) {
//		
//		user.setPassword(passwordEncode.encode(user.getPassword()));
//		user.setRole("ROLE_USER");
//		return userRepo.save(user);
//	}
//	@Override
//	public boolean checkEmail(String email) {
//		return userRepo.existsByEmail(email);
//	}
//}

package com.can.service;

import java.security.SecureRandom;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.can.Model.UserDtls;
import com.can.Repo.UserRepository;

import jakarta.annotation.PostConstruct;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private BCryptPasswordEncoder passwordEncode;

    @Autowired
    private JavaMailSender mailSender;
    
    @Value("${twilio.accountSid}")
    private String accountSid;

    @Value("${twilio.authToken}")
    private String authToken;

    @Value("${twilio.fromPhoneNumber}")
    private String fromPhoneNumber;
    
    @PostConstruct
    public void initTwilio() {
        Twilio.init(accountSid, authToken);
    }

    @Override
    public UserDtls creatUser(UserDtls user) {
        user.setPassword(passwordEncode.encode(user.getPassword()));
        user.setRole("ROLE_USER");
        return userRepo.save(user);
    }

    @Override
    public boolean checkEmail(String email) {
        return userRepo.existsByEmail(email);
    }

    @Override
    public String generateOtp() {
        int length = 6;
        String characters = "0123456789";
        Random random = new SecureRandom();
        StringBuilder otp = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            otp.append(characters.charAt(random.nextInt(characters.length())));
        }
        return otp.toString();
    }

    @Override
    public void handleForgotPassword(String email) {
        String otp = generateOtp();
        sendOtpToEmail(email, otp);
        System.out.println("handle " + otp);
    }

    @Override
    public void sendOtpToEmail(String email, String otp) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setTo(email);
            helper.setSubject("OTP for Password Reset");
            helper.setText("Your OTP for password reset is: " + otp
            				+" Link for create new password"+ " http://localhost:8082/verifyOtp");
            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
            // Handle exception or logging here
        }
    }

    @Override
    public void sendOtpToMobile(String mobile, String otp) {
        try {
        	 if (!mobile.startsWith("+")) {
                 mobile = "+" + mobile;
             }
            Message message = Message.creator(
                    new PhoneNumber(mobile),  // To number
                    new PhoneNumber(fromPhoneNumber),  // From number
                    "Your OTP for password reset is: " + otp
            ).create();
            System.out.println("Sent OTP to mobile: " + mobile + " OTP: " + otp);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to send OTP to mobile: " + mobile + " Error: " + e.getMessage());
        }
    }
}

