package com.can.service;

import org.springframework.stereotype.Service;

import com.can.Model.UserDtls;

@Service
public interface UserService {
	public UserDtls creatUser(UserDtls user);
	public boolean checkEmail(String email);
	public void handleForgotPassword(String email);
    public String generateOtp();
    public void sendOtpToEmail(String email, String otp);
    public void sendOtpToMobile(String mobile, String otp);
	

}
