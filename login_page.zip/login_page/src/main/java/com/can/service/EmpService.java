package com.can.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.can.Model.Employee;
import com.can.Repo.EmpRepo;

@Service
public class EmpService {

    @Autowired
    private EmpRepo repo;

    private final String uploadDirectory = "C:/uploads"; // Directory to save PDFs

    public void addEmp(Employee e, MultipartFile file) throws IOException {
        if (file != null && !file.isEmpty()) {
            String pdfFileName = file.getOriginalFilename();
            Path filePath = Paths.get(uploadDirectory, pdfFileName);
            Files.copy(file.getInputStream(), filePath);
            e.setPdfFileName(pdfFileName); // Save the file name to the employee object
        }
        repo.save(e);
    }

    public List<Employee> getAllEmp() {
        return repo.findAll();
    }

    public Employee getEmpById(int id) {
        Optional<Employee> e = repo.findById(id);
        return e.orElse(null);
    }

    public void deleteEmp(int id) {
        repo.deleteById(id);
    }
}
